from tablica import *

if __name__ == '__main__':
    tablica = Tablica(5)
    tablica.wypelnij(1, 10)
    print("Wygenerowana tablica:", tablica.pokaz_tablice())
    szukana_wartosc = 5
    wynik = tablica.znajdz(szukana_wartosc)
    if wynik != -1:
        print(f"Znaleziono wartość: {wynik}")
    else:
        print(f"Nie znaleziono wartości: {szukana_wartosc}")