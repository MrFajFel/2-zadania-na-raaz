import random

class Tablica:
    def __init__(self, n):
        self.__n = n
        self.__tab = []

    def wypelnij(self, a, b):
        for i in range(self.__n):
            losowanie = random.randint(a, b)
            self.__tab.append(losowanie)
            print(losowanie)

    def maksimum(self):
        if not self.__tab:
            return None
        max_value = self.__tab[0]
        for i in range(1, self.__n):
            if max_value < self.__tab[i]:
                max_value = self.__tab[i]
        return max_value

    def minimum(self):
        if not self.__tab:
            return None
        min_value = self.__tab[0]
        for i in range(1, self.__n):
            if min_value > self.__tab[i]:
                min_value = self.__tab[i]
        return min_value


    def max2(self):
        print('Nie umiem')

    def znajdz(self, a):
        for i in range(self.__n):
            if self.__tab[i] == a:
                return a
        return -1


    def pokaz_tablice(self):
        return self.__tab
